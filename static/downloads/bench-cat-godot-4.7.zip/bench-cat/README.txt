Bench Cat
=========

The Bench Cat game from The Creator Starter Kit: Games, built exactly as
the book builds it in Chapters 4, 6 and 7. Biscuit the cat chases a red
dot (your mouse pointer) along the kitchen bench. When Biscuit passes the
edge of the bench, there's a thump and a flash.

Every line of code has a plain-English comment above it, in the book's
words. The code itself is the same as the code printed in the book.

How to open it
--------------

You need Godot 4.7 (free, from godotengine.org).

1. Right-click the zip, choose Extract All, and extract it to
   C:\GodotProjects. You get a bench-cat folder.
2. In Godot's Project Manager, click Import (top left).
3. Click Browse, open C:\GodotProjects\bench-cat, and click Select This
   Folder. Godot says "Valid project found at path".
4. Leave Edit Now ticked and click Import.
5. If you see a 3D grid, click 2D at the top of the screen.
6. Click play (top right), then move the mouse pointer around, and hold
   it to the right of the bench.

What you'll see
---------------

Biscuit chases the dot anywhere, even through the air: this is Chapter
7's code, which moves straight towards the dot. The thump and flash
happen once, the first time Biscuit passes the bench edge. Click play
again to see it again. A version where Biscuit jumps and falls is coming
to Creator Crew.

What's inside
-------------

project.godot             The project's settings: its name, the window
                          size (1152 x 648) and the Compatibility renderer.
bench_cat.tscn            The main scene: Node2D, with Background,
                          Biscuit (and its Thump sound) and Dot.
scripts/biscuit.gd        Biscuit's script, from Chapter 7: chase the
                          dot, and land with a thump and a flash.
scripts/dot.gd            Dot's script, from Chapter 6: follow the mouse
                          pointer.
scripts/chapter-04-robot.gd
                          Chapter 4's script, with the left wall from its
                          Try This. Not attached to anything: Biscuit's
                          script replaced it in Chapter 7. Here to read.
art/biscuit.svg           Biscuit.
art/dot.svg               The red dot.
art/kitchen.svg           The kitchen. The bench ends at 900 pixels from
                          the left, the same 900 as in Biscuit's script.
sounds/thump.wav          The thump.
tools/make_thump.py       The Python script that made thump.wav. Godot
                          skips this folder (that's what .gdignore does).
*.import, *.uid           Godot's notes about each file. Leave them be.
LICENSE.txt               CC0: use any of it, no conditions.
CREDITS.txt               Who made what, and Godot's licence notice.

Godot shows one yellow warning for dot.gd: the parameter "delta" is
never used. That's fine. The book's code doesn't need it there.

More help with Godot: creatorcrew.com.au/godot
