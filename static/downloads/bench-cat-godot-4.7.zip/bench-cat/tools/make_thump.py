"""Makes sounds/thump.wav: a short, soft thud, like a rolled-up sock
dropped on a bench. Generated from scratch, so it's original (CC0).

Usage (from the project folder): python tools/make_thump.py

A low tone that drops in pitch and dies away fast, with a puff of soft
noise at the start for the contact. Fixed random seed, so it makes the
same file every time. Standard library only.
"""
import math
import os
import random
import struct
import wave

RATE = 44100            # samples a second
LENGTH = 0.28           # seconds
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "sounds", "thump.wav")


def thump():
    rng = random.Random(7)
    n = int(RATE * LENGTH)
    samples = []
    phase = 0.0
    noise = 0.0
    for i in range(n):
        t = i / RATE
        # the body of the thud: 110 Hz falling to about 55 Hz
        freq = 55 + 55 * math.exp(-t * 18)
        phase += 2 * math.pi * freq / RATE
        tone = math.sin(phase) * math.exp(-t * 22)
        # the contact: soft noise, smoothed so it's a puff, not a hiss
        noise += (rng.uniform(-1, 1) - noise) * 0.08
        puff = noise * math.exp(-t * 90) * 1.6
        # a few milliseconds' fade-in, so it doesn't click
        attack = min(1.0, t / 0.003)
        samples.append((tone * 0.8 + puff) * attack)
    peak = max(abs(s) for s in samples)
    return [s / peak * 0.7 for s in samples]


def main():
    data = b"".join(struct.pack("<h", int(round(s * 32767))) for s in thump())
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with wave.open(OUT, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(data)
    print(f"Wrote {os.path.normpath(OUT)}")


if __name__ == "__main__":
    main()
