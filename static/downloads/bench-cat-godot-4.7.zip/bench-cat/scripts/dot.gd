# This script is for a picture: the red dot. (Chapter 6)
extends Sprite2D

# Do the line below over and over, about sixty times a second.
func _process(delta):
	# Jump to wherever the mouse pointer is.
	position = get_global_mouse_position()
