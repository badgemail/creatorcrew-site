# This is the Chapter 4 version. Biscuit's script replaced it in Chapter 7.
# It's here to read and compare. It isn't attached to anything.

# This script is for a picture.
extends Sprite2D

# Do the lines below over and over, about sixty times a second.
func _process(delta):
	# Check which arrow keys are being held down.
	var dir = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	# Move the picture that way, 400 pixels a second.
	position += dir * 400 * delta
	# If the picture is more than 900 pixels from the left...
	if position.x > 900:
		# ...put it back at 900. That's the right wall.
		position.x = 900
	# If the picture is less than 64 pixels from the left...
	if position.x < 64:
		# ...put it back at 64. That's the left wall: half the robot's width.
		position.x = 64
