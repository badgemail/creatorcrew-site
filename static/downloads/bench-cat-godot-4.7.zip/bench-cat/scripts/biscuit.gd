# This script is for a picture: Biscuit. (Chapter 7)
extends Sprite2D

# Biscuit starts on the bench.
var on_bench = true

# Do the lines below over and over, about sixty times a second.
func _process(delta):
	# Find the Dot node.
	var dot = get_node("../Dot")
	# Walk a little closer to the dot, 300 pixels a second.
	position = position.move_toward(dot.position, 300 * delta)
	# If Biscuit is still on the bench and has passed the edge...
	if on_bench and position.x > 900:
		# ...Biscuit isn't on the bench any more, so this only happens once...
		on_bench = false
		# ...and do the landing.
		land()

# Here's what landing means:
func land():
	# Play the Thump sound. The name must match the node's exactly.
	$Thump.play()
	# Make Biscuit twice as bright.
	modulate = Color(2, 2, 2)
	# Fade back to normal over 0.15 seconds.
	create_tween().tween_property(self, "modulate", Color.WHITE, 0.15)
